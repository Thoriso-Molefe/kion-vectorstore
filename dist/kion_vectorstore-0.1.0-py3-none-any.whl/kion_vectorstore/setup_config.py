import os
import shutil
try:
    import importlib.resources as pkg_resources
except ImportError:
    # Use the backport for Python < 3.7
    import importlib_resources as pkg_resources

def create_env_file(destination_dir=None, force=False):
    """
    Moves the template .env file from the package to a specified directory.

    Args:
        destination_dir (str, optional): The directory to save the .env file. 
                                         Defaults to the current working directory.
        force (bool, optional): If True, overwrites an existing .env file. 
                                Defaults to False.
    """
    if destination_dir is None:
        destination_dir = os.getcwd()
    
    # Ensure the target directory exists
    os.makedirs(destination_dir, exist_ok=True)

    # ENV SET-UP VARIABLES
    # Define the environment set-up filenames
    env_filename = ".env"
    dotenv_finder_filename = "dotenv_finder.py"
    env_destination_path = os.path.join(destination_dir, env_filename)
    dotenv_finder_destination_path = os.path.join(destination_dir, dotenv_finder_filename)
    print(f"Initializing .env file in: {os.path.abspath(destination_dir)}")

    # APP LAUNCH VARIABLES
    # Define the app launch filename
    # Define app folder
    app_filename = "app.py"

    # app_gui_destination_dir = "static"
    # app_gui_filenames = [
    #                      "file_loader_gui.html",
    #                      "file_remover_gui.html",
    #                      "chat.html",
    #                      "kion_logo.png"
    #                      ]
    
    # README file
    readme_filename = "README.md"

    # os.makedirs(app_gui_destination_dir, exist_ok=True)
    
    # Check if the env setup files exists and if we should skip
    if os.path.exists(env_destination_path) and not force:
        print(f"- Skipping '{env_filename}': File already exists. Use --force to overwrite.")
        return
    if os.path.exists(dotenv_finder_destination_path) and not force:
        print(f"- Skipping '{dotenv_finder_filename}': File already exists. Use --force to overwrite.")
        return
    
    #The .env file
    try:
        # Safely access the .env file within the installed package
        with pkg_resources.path('kion_vectorstore', env_filename) as source_path:
            # Copy the file to the destination
            shutil.copy2(source_path, env_destination_path)
            if force and os.path.exists(env_destination_path):
                 print(f"- Successfully overwrote '{env_filename}'.")
            else:
                 print(f"- Successfully created '{env_filename}'.")         
    except FileNotFoundError:
        print(f"Error: Could not find '{env_filename}' template within the package. Ensure it's included in 'package_data' in setup.py.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

    # The app file
    try:
        # Safely access the app file within the installed package
        with pkg_resources.path('kion_vectorstore', app_filename) as source_path:
            # Copy the file to the destination
            shutil.copy2(source_path, app_filename)
            if force and os.path.exists(app_filename):
                 print(f"- Successfully overwrote '{app_filename}'.")
            else:
                 print(f"- Successfully created '{app_filename}'.")         
    except FileNotFoundError:
        print(f"Error: Could not find '{app_filename}' template within the package. Ensure it's included in 'package_data' in setup.py.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

    # # the html files
    # for app_gui_filename in app_gui_filenames:
    #     app_gui_destination_path = os.path.join(app_gui_destination_dir, app_gui_filename)
    #     try:
    #         # Safely access the app_launch file within the installed package
    #         with pkg_resources.path('kion_vectorstore', app_gui_destination_path) as source_path:
    #             # Copy the file to the destination
    #             shutil.copy2(source_path, app_gui_destination_path)
    #             if force and os.path.exists(app_gui_destination_path):
    #                 print(f"- Successfully overwrote '{app_gui_destination_path}'.")
    #             else:
    #                 print(f"- Successfully created '{app_gui_destination_path}'.")
    #     except FileNotFoundError:
    #         print(f"Error: Could not find '{app_gui_filename}' template within the package. Ensure it's included in 'package_data' in setup.py.")
    #     except Exception as e:
    #         print(f"An unexpected error occurred: {e}")

    try:
        # Safely access the app_launch file within the installed package
        with pkg_resources.path('kion_vectorstore', readme_filename) as source_path:
            # Copy the file to the destination
            shutil.copy2(source_path, readme_filename)
            if force and os.path.exists(readme_filename):
                 print(f"- Successfully overwrote '{readme_filename}'.")
            else:
                 print(f"- Successfully created '{readme_filename}'.")
    except FileNotFoundError:
        print(f"Error: Could not find '{readme_filename}' template within the package. Ensure it's included in 'package_data' in setup.py.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")