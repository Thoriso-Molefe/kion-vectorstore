# kion_vectorstore/cli_init_env.py

import argparse
# Correctly import the renamed function
from kion_vectorstore.setup_config import create_env_file

def main():
    """
    The main function for the kionrag-env-init command-line tool.
    """
    parser = argparse.ArgumentParser(
        prog="kionrag-env-init",
        description="Kion Vectorstore Initializer: A tool to create an initial .env file for your project."
    )

    parser.add_argument(
        '--path',
        type=str,
        default=None,
        help="The directory where the .env file will be created. Defaults to the current directory."
    )
    
    parser.add_argument(
        '-f', '--force',
        action='store_true',
        help="Force overwrite of an existing .env file."
    )

    args = parser.parse_args()

    # Call the corrected function with the parsed arguments
    create_env_file(destination_dir=args.path, force=args.force)

if __name__ == '__main__':
    main()